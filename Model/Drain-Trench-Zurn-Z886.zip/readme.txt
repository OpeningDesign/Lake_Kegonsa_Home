This ZIP file contains a Revit family as well as supporting files that are integral to the function of the family in a project. 

The Fallowing files must be extracted into the same folder in order to work properly:
The family, <Family Name>.rfa 
The shared parameters <Zurn_Product>.txt
Extract these files to the Revit library or to the library of your choice. 
The Revit library is typically installed in C:\Documents and Settings\All Users\Application Data\Autodesk\<Revit release name>\Imperial Library. 

The look up table <Family Name>.csv
 Extract to this file to the Lookup Tables folder, typically installed in C:\Documents and Settings\All Users\Application Data\Autodesk\<Revit MEP release name>. 

All other files including this readme file do not affect the function of the family in Revit software and can be downloaded to any location or not at all.

Files and models created by EMA Design Automation www.ema-eda.com
		 